# ==================== 导入必要的库 ====================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体和样式
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
sns.set_style("whitegrid")
plt.style.use('seaborn-v0_8-darkgrid')

print("✅ 环境准备完成")

# ==================== 第一部分：数据生成与预处理 ====================
def generate_sample_data(num_students=300, num_classes=6):
    """生成模拟成绩数据"""
    np.random.seed(42)  # 固定随机种子，确保结果可复现
    
    # 生成学生信息
    classes = [f'高{(i//50)+1}班({i%50+1:02d})' for i in range(num_students)]
    student_ids = [f'S{2024000+i:03d}' for i in range(num_students)]
    student_names = [f'学生{i+1}' for i in range(num_students)]
    
    # 生成成绩数据 - 不同学科有不同的分布特征
    data = {
        '学号': student_ids,
        '姓名': student_names,
        '班级': np.random.choice([f'高三({i+1})班' for i in range(num_classes)], num_students),
        '语文': np.clip(np.random.normal(85, 12, num_students), 0, 100).round(1),
        '数学': np.clip(np.random.normal(78, 18, num_students), 0, 100).round(1),
        '英语': np.clip(np.random.normal(82, 10, num_students), 0, 100).round(1),
        '物理': np.clip(np.random.normal(70, 20, num_students) + 10, 0, 100).round(1),
        '化学': np.clip(np.random.normal(75, 15, num_students), 0, 100).round(1),
        '生物': np.clip(np.random.normal(80, 14, num_students), 0, 100).round(1),
    }
    
    # 创建DataFrame
    df = pd.DataFrame(data)
    
    # 计算总分和平均分
    subjects = ['语文', '数学', '英语', '物理', '化学', '生物']
    df['总分'] = df[subjects].sum(axis=1).round(1)
    df['平均分'] = (df['总分'] / len(subjects)).round(1)
    
    # 添加学生类型标签（模拟）
    df['学生类型'] = pd.cut(df['平均分'], 
                          bins=[0, 60, 75, 85, 100], 
                          labels=['待提升', '良好', '优秀', '卓越'])
    
    return df, subjects

# 生成模拟数据
df, subjects = generate_sample_data(num_students=300, num_classes=6)
print("✅ 模拟数据生成完成")
print(f"数据维度: {df.shape}")
print("\n数据预览:")
print(df.head())
print("\n数据基本信息:")
print(df.info())

# ==================== 第二部分：基础统计分析函数 ====================
def calculate_basic_statistics(df, subjects):
    """计算基础统计指标"""
    stats_dict = {}
    
    for subject in subjects + ['总分', '平均分']:
        stats_dict[subject] = {
            '平均分': df[subject].mean(),
            '中位数': df[subject].median(),
            '最高分': df[subject].max(),
            '最低分': df[subject].min(),
            '标准差': df[subject].std(),
            '及格率': (df[subject] >= 60).mean() * 100,
            '优秀率': (df[subject] >= 85).mean() * 100,
            '优良率': (df[subject] >= 75).mean() * 100,
            '低分率': (df[subject] < 60).mean() * 100,
            '变异系数': (df[subject].std() / df[subject].mean()) * 100 if df[subject].mean() > 0 else 0
        }
    
    # 转为DataFrame方便查看
    stats_df = pd.DataFrame(stats_dict).T.round(2)
    
    return stats_df

# 计算全校统计
school_stats = calculate_basic_statistics(df, subjects)
print("\n📊 全校基础统计指标:")
print(school_stats)

# ==================== 第三部分：班级对比分析 ====================
def class_comparison_analysis(df, subjects):
    """班级对比分析"""
    # 1. 班级各科平均分对比
    class_subject_avg = df.groupby('班级')[subjects].mean().round(1)
    
    # 2. 班级整体指标
    class_stats = df.groupby('班级').agg({
        '总分': ['mean', 'std', 'max', 'min'],
        '平均分': 'mean',
        '学号': 'count'  # 班级人数
    }).round(2)
    
    # 重命名列
    class_stats.columns = ['班级平均总分', '总分标准差', '班级最高分', '班级最低分', '班级平均分', '班级人数']
    
    # 3. 计算班级排名
    class_stats['总分排名'] = class_stats['班级平均总分'].rank(ascending=False).astype(int)
    class_stats['平均分排名'] = class_stats['班级平均分'].rank(ascending=False).astype(int)
    
    # 4. 计算班级四率（及格率、优秀率等）
    for subject in subjects + ['总分']:
        class_stats[f'{subject}及格率'] = df.groupby('班级')[subject].apply(
            lambda x: (x >= 60).mean() * 100
        ).round(2)
        class_stats[f'{subject}优秀率'] = df.groupby('班级')[subject].apply(
            lambda x: (x >= 85).mean() * 100
        ).round(2)
    
    return class_subject_avg, class_stats

# 执行班级分析
class_subject_avg, class_stats = class_comparison_analysis(df, subjects)
print("\n📈 班级对比分析:")
print("各班级学科平均分:")
print(class_subject_avg)
print("\n班级整体指标:")
print(class_stats)

# ==================== 第四部分：学生个体分析 ====================
def student_individual_analysis(df, subjects):
    """学生个体分析"""
    # 1. 计算学生标准分（Z分数）
    zscore_df = df.copy()
    for subject in subjects:
        mean_val = df[subject].mean()
        std_val = df[subject].std()
        if std_val > 0:  # 避免除零错误
            zscore_df[f'{subject}_Z'] = (df[subject] - mean_val) / std_val
    
    # 2. 计算学生总分排名和百分比
    zscore_df['总分排名'] = zscore_df['总分'].rank(ascending=False, method='min').astype(int)
    zscore_df['总分百分比'] = (zscore_df['总分排名'] / len(zscore_df) * 100).round(1)
    
    # 3. 计算学生学科均衡性（各科Z分数的标准差）
    zscore_columns = [f'{subject}_Z' for subject in subjects]
    zscore_df['学科均衡性'] = zscore_df[zscore_columns].std(axis=1).round(3)
    
    # 4. 识别临界生
    total_avg = df['平均分'].mean()
    total_std = df['平均分'].std()
    
    def identify_student_type(score):
        if score >= total_avg + total_std:
            return '优势生'
        elif score >= total_avg:
            return '良好生'
        elif score >= total_avg - total_std:
            return '临界生'
        else:
            return '待提升生'
    
    zscore_df['学生水平'] = zscore_df['平均分'].apply(identify_student_type)
    
    return zscore_df

# 执行学生个体分析
student_analysis_df = student_individual_analysis(df, subjects)
print("\n👤 学生个体分析示例（前5名学生）:")
print(student_analysis_df[['学号', '姓名', '班级', '总分', '平均分', '总分排名', '总分百分比', '学生水平', '学科均衡性']].head())

# ==================== 第五部分：数据可视化 ====================
def create_visualizations(df, class_stats, class_subject_avg, subjects):
    """创建可视化图表"""
    fig = plt.figure(figsize=(20, 16))
    
    # 1. 全校成绩分布直方图
    ax1 = plt.subplot(3, 3, 1)
    plt.hist(df['总分'], bins=20, edgecolor='black', alpha=0.7, color='steelblue')
    plt.axvline(df['总分'].mean(), color='red', linestyle='--', linewidth=2, label=f'平均分: {df["总分"].mean():.1f}')
    plt.xlabel('总分')
    plt.ylabel('学生人数')
    plt.title('全校总分分布直方图')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 2. 各科平均分对比
    ax2 = plt.subplot(3, 3, 2)
    subject_means = df[subjects].mean().sort_values()
    colors = plt.cm.viridis(np.linspace(0, 1, len(subjects)))
    bars = plt.barh(range(len(subjects)), subject_means, color=colors, alpha=0.7)
    plt.yticks(range(len(subjects)), subject_means.index)
    plt.xlabel('平均分')
    plt.title('各学科平均分对比')
    
    # 添加数值标签
    for i, v in enumerate(subject_means):
        plt.text(v + 0.5, i, f'{v:.1f}', va='center')
    
    # 3. 班级平均分对比
    ax3 = plt.subplot(3, 3, 3)
    class_order = class_stats.sort_values('班级平均分', ascending=False).index
    class_means = class_stats.loc[class_order, '班级平均分']
    colors = plt.cm.plasma(np.linspace(0.2, 0.8, len(class_means)))
    bars = plt.bar(range(len(class_means)), class_means, color=colors, alpha=0.7)
    plt.xticks(range(len(class_means)), class_order, rotation=45, ha='right')
    plt.xlabel('班级')
    plt.ylabel('班级平均分')
    plt.title('各班级平均分对比')
    
    # 添加排名标签
    for i, (idx, row) in enumerate(class_stats.loc[class_order].iterrows()):
        plt.text(i, row['班级平均分'] + 0.1, f"第{int(row['平均分排名'])}名", 
                ha='center', va='bottom', fontsize=9)
    
    # 4. 学科相关性热力图
    ax4 = plt.subplot(3, 3, 4)
    correlation_matrix = df[subjects].corr()
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', 
                center=0, square=True, linewidths=1, 
                cbar_kws={"shrink": 0.8})
    plt.title('学科成绩相关性热力图')
    
    # 5. 班级各科平均分热力图
    ax5 = plt.subplot(3, 3, 5)
    sns.heatmap(class_subject_avg.T, annot=True, fmt='.1f', 
                cmap='YlOrRd', linewidths=1)
    plt.title('班级各科平均分热力图')
    plt.ylabel('学科')
    plt.xlabel('班级')
    
    # 6. 学生类型分布饼图
    ax6 = plt.subplot(3, 3, 6)
    student_type_counts = df['学生类型'].value_counts()
    colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99']
    wedges, texts, autotexts = plt.pie(student_type_counts.values, 
                                      labels=student_type_counts.index,
                                      autopct='%1.1f%%',
                                      colors=colors,
                                      startangle=90,
                                      shadow=True)
    plt.title('学生类型分布')
    
    # 7. 各科箱线图（异常值检测）
    ax7 = plt.subplot(3, 3, 7)
    df[subjects].boxplot(grid=True, fontsize=10)
    plt.xticks(rotation=45, ha='right')
    plt.title('各学科成绩箱线图')
    plt.ylabel('分数')
    
    # 8. 班级及格率对比
    ax8 = plt.subplot(3, 3, 8)
    class_order = class_stats.sort_values('班级平均总分', ascending=False).index
    classes = class_order.tolist()
    
    # 为每个班级选择一门主要科目展示及格率（这里用语文）
    pass_rates = [class_stats.loc[cls, '语文及格率'] for cls in classes]
    
    x = np.arange(len(classes))
    bars = plt.bar(x, pass_rates, color='lightgreen', alpha=0.7, edgecolor='darkgreen')
    plt.xticks(x, classes, rotation=45, ha='right')
    plt.ylabel('及格率 (%)')
    plt.title('各班级语文及格率对比')
    plt.ylim([0, 105])
    
    # 添加及格率数值
    for i, v in enumerate(pass_rates):
        plt.text(i, v + 1, f'{v:.1f}%', ha='center', fontsize=9)
    
    # 9. 学生成绩雷达图示例（展示前3名学生）
    ax9 = plt.subplot(3, 3, 9, projection='polar')
    
    # 选择前3名学生
    top_students = df.nlargest(3, '总分')
    
    # 雷达图数据准备
    angles = np.linspace(0, 2*np.pi, len(subjects), endpoint=False).tolist()
    angles += angles[:1]  # 闭合图形
    
    for i, (_, student) in enumerate(top_students.iterrows()):
        values = student[subjects].tolist()
        values += values[:1]  # 闭合图形
        
        # 归一化到0-1范围
        values_norm = [(v - df[subjects].min().min()) / 
                      (df[subjects].max().max() - df[subjects].min().min()) 
                      for v in values]
        
        ax9.plot(angles, values_norm, 'o-', linewidth=2, 
                label=f"{student['姓名']} (总分:{student['总分']})", 
                alpha=0.7)
        ax9.fill(angles, values_norm, alpha=0.1)
    
    ax9.set_xticks(angles[:-1])
    ax9.set_xticklabels(subjects)
    ax9.set_title('优秀学生学科雷达图')
    ax9.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=9)
    
    plt.suptitle('成绩分析可视化仪表板', fontsize=16, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.show()
    
    # 创建额外的进阶图表
    create_advanced_visualizations(df, subjects)

def create_advanced_visualizations(df, subjects):
    """创建进阶分析图表"""
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # 1. 总分与单科关系散点图（以数学为例）
    ax1 = axes[0, 0]
    scatter = ax1.scatter(df['数学'], df['总分'], 
                         c=df['英语'],  # 用英语成绩作为颜色维度
                         cmap='viridis', 
                         alpha=0.6, 
                         s=50, 
                         edgecolors='w', 
                         linewidth=0.5)
    
    # 添加回归线
    z = np.polyfit(df['数学'], df['总分'], 1)
    p = np.poly1d(z)
    ax1.plot(df['数学'], p(df['数学']), "r--", alpha=0.8, linewidth=2)
    
    ax1.set_xlabel('数学成绩')
    ax1.set_ylabel('总分')
    ax1.set_title('数学成绩与总分关系（颜色表示英语成绩）')
    plt.colorbar(scatter, ax=ax1, label='英语成绩')
    
    # 计算相关系数
    corr = df['数学'].corr(df['总分'])
    ax1.text(0.05, 0.95, f'相关系数: {corr:.3f}', 
             transform=ax1.transAxes, fontsize=10,
             verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # 2. 学生成绩分布核密度估计
    ax2 = axes[0, 1]
    for subject in subjects[:3]:  # 只展示前3科避免太拥挤
        sns.kdeplot(data=df, x=subject, label=subject, ax=ax2, linewidth=2)
    
    ax2.set_xlabel('分数')
    ax2.set_ylabel('密度')
    ax2.set_title('学科成绩分布核密度估计')
    ax2.legend()
    
    # 3. 学生类型在各班级的分布
    ax3 = axes[1, 0]
    cross_tab = pd.crosstab(df['班级'], df['学生类型'], normalize='index') * 100
    cross_tab.plot(kind='bar', stacked=True, ax=ax3, colormap='Set2')
    ax3.set_xlabel('班级')
    ax3.set_ylabel('百分比 (%)')
    ax3.set_title('各班级学生类型分布')
    ax3.legend(title='学生类型', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.xticks(rotation=45, ha='right')
    
    # 4. 累积分布函数图
    ax4 = axes[1, 1]
    for subject in subjects[:3]:  # 只展示前3科
        sorted_data = np.sort(df[subject])
        yvals = np.arange(1, len(sorted_data)+1)/float(len(sorted_data))
        ax4.plot(sorted_data, yvals * 100, linewidth=2, label=subject)
    
    ax4.set_xlabel('分数')
    ax4.set_ylabel('累积百分比 (%)')
    ax4.set_title('学科成绩累积分布函数')
    ax4.legend()
    ax4.grid(True, alpha=0.3)
    
    plt.suptitle('进阶分析图表', fontsize=16, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.show()

# 执行可视化
print("\n📊 正在生成可视化图表...")
create_visualizations(df, class_stats, class_subject_avg, subjects)

# ==================== 第六部分：生成分析报告 ====================
def generate_analysis_report(df, class_stats, school_stats, subjects):
    """生成文本分析报告"""
    report = []
    report.append("=" * 60)
    report.append("成绩分析报告")
    report.append("=" * 60)
    
    # 1. 基本情况
    report.append("\n一、基本情况")
    report.append(f"分析时间: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"学生总数: {len(df)} 人")
    report.append(f"班级数量: {df['班级'].nunique()} 个")
    report.append(f"分析科目: {', '.join(subjects)}")
    
    # 2. 全校整体情况
    report.append("\n二、全校整体情况")
    total_mean = df['总分'].mean()
    total_std = df['总分'].std()
    report.append(f"全校平均总分: {total_mean:.1f} 分")
    report.append(f"总分标准差: {total_std:.1f} (离散程度)")
    report.append(f"总分变异系数: {(total_std/total_mean*100):.1f}%")
    report.append(f"最高分: {df['总分'].max():.1f} 分")
    report.append(f"最低分: {df['总分'].min():.1f} 分")
    report.append(f"全距: {df['总分'].max() - df['总分'].min():.1f} 分")
    
    # 3. 各学科表现
    report.append("\n三、各学科表现")
    best_subject = school_stats.loc[subjects, '平均分'].idxmax()
    worst_subject = school_stats.loc[subjects, '平均分'].idxmin()
    report.append(f"优势学科: {best_subject} (平均分: {school_stats.loc[best_subject, '平均分']:.1f}分)")
    report.append(f"薄弱学科: {worst_subject} (平均分: {school_stats.loc[worst_subject, '平均分']:.1f}分)")
    
    # 4. 班级表现
    report.append("\n四、班级表现")
    best_class = class_stats['班级平均分'].idxmax()
    worst_class = class_stats['班级平均分'].idxmin()
    report.append(f"表现最佳班级: {best_class} (平均分: {class_stats.loc[best_class, '班级平均分']:.1f}分)")
    report.append(f"需要关注班级: {worst_class} (平均分: {class_stats.loc[worst_class, '班级平均分']:.1f}分)")
    
    # 5. 学生群体分析
    report.append("\n五、学生群体分析")
    student_type_counts = df['学生类型'].value_counts()
    for stype, count in student_type_counts.items():
        percentage = count / len(df) * 100
        report.append(f"{stype}: {count}人 ({percentage:.1f}%)")
    
    # 6. 主要发现与建议
    report.append("\n六、主要发现与建议")
    
    # 识别需要关注的学科
    low_pass_subjects = school_stats.loc[subjects][school_stats.loc[subjects, '及格率'] < 80].index.tolist()
    if low_pass_subjects:
        report.append(f"1. 需要关注学科: {', '.join(low_pass_subjects)} 及格率低于80%")
        report.append(f"   建议: 加强这些学科的基础教学，开展针对性辅导")
    
    # 识别分化严重的班级
    high_std_classes = class_stats[class_stats['总分标准差'] > class_stats['总分标准差'].mean() * 1.2].index.tolist()
    if high_std_classes:
        report.append(f"2. 班级分化严重: {', '.join(high_std_classes)} 内部成绩差异较大")
        report.append(f"   建议: 实施分层教学，关注后进生")
    
    # 识别优秀学生比例低的班级
    low_excellent_classes = class_stats[class_stats['语文优秀率'] < 20].index.tolist()
    if low_excellent_classes:
        report.append(f"3. 优秀生培养待加强: {', '.join(low_excellent_classes)} 优秀率偏低")
        report.append(f"   建议: 设置培优课程，激发学生潜力")
    
    report.append("\n" + "=" * 60)
    report.append("报告结束")
    report.append("=" * 60)
    
    return "\n".join(report)

# 生成并打印报告
print("\n📋 正在生成分析报告...")
report = generate_analysis_report(df, class_stats, school_stats, subjects)
print(report)

# ==================== 第七部分：导出分析结果 ====================
def export_results(df, student_analysis_df, class_stats, school_stats):
    """导出分析结果到Excel"""
    # 创建Excel写入器
    with pd.ExcelWriter('成绩分析报告.xlsx', engine='openpyxl') as writer:
        # 1. 原始数据（清理后）
        df.to_excel(writer, sheet_name='原始数据', index=False)
        
        # 2. 学生详细分析
        student_analysis_df.to_excel(writer, sheet_name='学生详细分析', index=False)
        
        # 3. 班级统计
        class_stats.to_excel(writer, sheet_name='班级统计')
        
        # 4. 学科统计
        school_stats.to_excel(writer, sheet_name='学科统计')
        
        # 5. 各班级学科平均分
        class_subject_avg.to_excel(writer, sheet_name='班级学科平均分')
        
        # 6. 关键指标汇总
        summary_data = {
            '指标': ['学生总数', '班级数', '全校平均总分', '全校平均分', 
                   '最高分', '最低分', '全距', '及格率', '优秀率'],
            '数值': [len(df), df['班级'].nunique(), 
                   df['总分'].mean(), df['平均分'].mean(),
                   df['总分'].max(), df['总分'].min(),
                   df['总分'].max() - df['总分'].min(),
                   (df['总分'] >= 60*len(subjects)).mean() * 100,
                   (df['总分'] >= 85*len(subjects)).mean() * 100]
        }
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='关键指标汇总', index=False)
    
    print("\n💾 分析结果已导出到: 成绩分析报告.xlsx")

# 导出结果
export_results(df, student_analysis_df, class_stats, school_stats)

# ==================== 第八部分：进阶分析功能 ====================
def advanced_analysis(df, subjects):
    """执行进阶统计分析"""
    print("\n🔬 进阶统计分析:")
    
    # 1. 正态性检验
    print("1. 成绩正态性检验 (Shapiro-Wilk检验):")
    for subject in subjects[:3]:  # 测试前3科
        stat, p_value = stats.shapiro(df[subject].sample(min(100, len(df))))  # Shapiro检验限制样本量
        normality = "近似正态分布" if p_value > 0.05 else "非正态分布"
        print(f"   {subject}: W={stat:.3f}, p={p_value:.3f} ({normality})")
    
    # 2. 班级间差异显著性检验（ANOVA）
    print("\n2. 班级间差异显著性检验 (单因素ANOVA):")
    groups = [df[df['班级']==cls]['总分'].values for cls in df['班级'].unique()]
    f_stat, p_value = stats.f_oneway(*groups)
    significance = "存在显著差异" if p_value < 0.05 else "无显著差异"
    print(f"   F={f_stat:.3f}, p={p_value:.3f} ({significance})")
    
    # 3. 计算百分位数
    print("\n3. 总分百分位数:")
    percentiles = [25, 50, 75, 90, 95]
    for p in percentiles:
        value = np.percentile(df['总分'], p)
        print(f"   前{p}%分数线: {value:.1f}分")
    
    # 4. 识别异常值
    print("\n4. 异常值检测 (基于IQR方法):")
    for subject in subjects:
        Q1 = df[subject].quantile(0.25)
        Q3 = df[subject].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        outliers = df[(df[subject] < lower_bound) | (df[subject] > upper_bound)]
        if len(outliers) > 0:
            print(f"   {subject}: 发现{len(outliers)}个异常值")

# 执行进阶分析
advanced_analysis(df, subjects)

print("\n🎉 成绩分析完成！")